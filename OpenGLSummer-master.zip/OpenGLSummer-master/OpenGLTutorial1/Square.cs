﻿using OpenGL;
using System;

namespace OpenGLTutorial1
{
    class Square
    {
        public float x, y;
        public Vector3 size;
        public Vector3 color;
        public Vector2 dirrection;
        static Random rnd = new Random();
        const int bounds = 2;
        public Square(Square parent1, Square parent2)
        {
        }
        public Square(float x, float y, float size, Vector3 color)
        {
            this.x = x;
            this.y = y;
            this.size = new Vector3(size, size, 1);
            this.color = color;
            this.dirrection = new Vector2(rnd.Next(-255, 256), rnd.Next(-255, 256)).Normalize() * 2;

        }
        public void move(float deltaTime)
        {
           
        }
        public void CheckBounds()
        {
            
        }
        public bool collide(Square other)
        {
             
            return false;
            
        }
    }
}
